INSTALLATION:
	Copy folder in C:\
Tools:
	WinRar is required
	You can find it in Tools folder

*****************************************************
WARNING:
	Run the program always as admin, otherwise the program can't mount and unmount devices.
	If you are using the program by "task scheduler" mark the "run as administrator" checkbox.